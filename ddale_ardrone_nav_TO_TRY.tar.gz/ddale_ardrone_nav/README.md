#Projet Dedale 2015-2016

## Description
	
Package ROS visant à effectuer un suivi de trajectoire pour ardrone 2.0 par detection de tag ar.

## Installation

	Initialize ROS & a catkin workspace
	Clone this repo to your catkin workspace source directory
	Issue a catkin_make command
	Source the setup.bash created in the devel folder of your catkin workspace

## Usage

	Start the ardrone driver
		$ roslaunch ddale_ardrone_nav ardrone_driver.launch
	Start the ardrone navigation
		$ roslaunch ddale_ardrone_nav ardrone_navigation.launch

## Contributing

1. Fork it!
2. Create your feature branch: `git checkout -b my-new-feature`
3. Commit your changes: `git commit -am 'Add some feature'`
4. Push to the branch: `git push origin my-new-feature`
5. Submit a pull request.

## License & Credits

Projet réalisé dans le cadre du projet GATE (cycle ingénieur première année Telecom-SudParis) par le groupe Dedale.

 + Authors Website: 
 + School webpage:
